/*
	Halcyonic by HTML5 UP
	html5up.net | @n33co
	Free for personal and commercial use under the CCA 3.0 license (html5up.net/license)
*/

(function($) {
	document.getElementById('test').onclick = TestClickHandler;
})(jQuery);

function TestClickHandler() {
	// redirect to the graphs here...
	window.location = "~/Graphs/Dashboard.html";
}