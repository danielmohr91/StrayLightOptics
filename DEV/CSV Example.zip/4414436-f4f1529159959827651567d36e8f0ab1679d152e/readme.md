This is a simple line graph designed to allow investigation of aspects of using d3.js and is used as a teaching aid.

It is the baseline example graph used in the [D3 Tips and Tricks](https://leanpub.com/D3-Tips-and-Tricks) book.

Edit: June 2014

I am going through a process of updating the code resources for the book and the latest (but not particularly different) example of this graph is [here](http://bl.ocks.org/d3noob/b3ff6ae1c120eea654b5).